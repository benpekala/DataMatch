//
//  ViewController.swift
//  DataMatch
//
//  Created by Frank on 12/31/18.
//  Copyright © 2018 Frank Kulaszewicz. All rights reserved.
//

import UIKit

class MenuViewController: UIViewController {

    @IBAction func Begin_Survey(_ sender: Any) {
        
    }
    
    @IBOutlet weak var DataMatch_Title: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

